import React from "react";
import Home from "../modules/home/home";

export default function HomePage() {
  return <Home />;
}
