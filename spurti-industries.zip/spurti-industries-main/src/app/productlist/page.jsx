import Productlist from "@/modules/productlist/productlist";
import React from "react";

const ProductListPage = () => {
  return <Productlist />;
};

export default ProductListPage;
