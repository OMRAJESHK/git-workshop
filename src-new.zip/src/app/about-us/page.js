import Aboutus from "@/modules/aboutus/aboutus";
import React from "react";

const AboutUsPage = () => {
  return <Aboutus />;
};

export default AboutUsPage;
