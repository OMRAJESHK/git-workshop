import Contactus from "@/modules/contactus/contactus";
import React from "react";

const ContactUsPage = () => {
  return <Contactus />;
};

export default ContactUsPage;
