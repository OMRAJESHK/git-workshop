import CustomImage from "./customImage";

export default CustomImage;
