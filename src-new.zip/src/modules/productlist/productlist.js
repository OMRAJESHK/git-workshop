"use client";
import React, { useState, useRef, useEffect } from "react";
import Slider from "react-slick";
import Wrapper from "../home/common/wrapper";
import Copyrights from "../common/copyrights";
import Footer from "../common/footer/footer";
import ContactUs from "../common/contactUs/contactUs";
import classes from "./productlist.module.css";

import img1 from "../../asset/images/image-13.jpg";
import img2 from "../../asset/images/image-2.jpg";
import img3 from "../../asset/images/image-5.jpg";
import img4 from "../../asset/images/image-6.jpg";
import img5 from "../../asset/images/image-7.jpg";
import img6 from "../../asset/images/image-8.jpg";
import img7 from "../../asset/images/image-9.jpg";

import CustomImage from "@/components/customImage";
import ArrowLeft from "@/components/carousel/arrowLeft";
import ArrowRight from "@/components/carousel/arrowRight";

const Productlist = () => {
  const [nav1, setNav1] = useState(null);
  const [nav2, setNav2] = useState(null);
  let sliderRef1 = useRef(null);
  let sliderRef2 = useRef(null);

  useEffect(() => {
    setNav1(sliderRef1);
    setNav2(sliderRef2);
  }, []);

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    prevArrow: <ArrowLeft />,
    nextArrow: <ArrowRight />,
  };

  return (
    <>
      <Wrapper>
        <div className={classes["product-wrapper"]}>
          <Slider
            asNavFor={nav2}
            ref={(slider) => (sliderRef1 = slider)}
            {...settings}
          >
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img1}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img2}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img3}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img4}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img5}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
            <div className={classes["product-main-img-wrapper"]}>
              <CustomImage
                src={img6}
                alt="logo"
                width={550}
                height={250}
                classProp={classes["product-img"]}
              />
            </div>
          </Slider>
          <Slider
            asNavFor={nav1}
            ref={(slider) => (sliderRef2 = slider)}
            slidesToShow={5}
            swipeToSlide={true}
            focusOnSelect={true}
            prevArrow={<ArrowLeft />}
            nextArrow={<ArrowRight />}
          >
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img1}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img2}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img3}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img4}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img5}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
            <div className={classes["product-thumbnail-wrapper"]}>
              <CustomImage
                src={img6}
                alt="logo"
                width={100}
                height={100}
                classProp={classes["product-thumbnail-img"]}
              />
            </div>
          </Slider>
        </div>
      </Wrapper>
      <ContactUs />
      <Footer />
      <Copyrights />
    </>
  );
};

export default Productlist;
