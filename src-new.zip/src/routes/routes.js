export const pageRoutes = {
  home: "/",
  aboutus: "/about-us",
  products: "/productlist",
  contactus: "/contact-us",
};
